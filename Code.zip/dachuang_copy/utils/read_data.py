from torch.utils.data import Dataset
from .yolov4.yolo import YOLO as yolo
import os
from PIL import Image
import numpy as np
import itertools
import torch

"""
目前主要用SMdataset类，其他dataset类不用管
"""

def collate_fn(data): #定义批量读取数据的过程，不用管
    id_list = [i[0] for i in data]
    label_list = torch.FloatTensor([i[2] for i in data])
    sag_list = [i[1][1] for i in data]
    tra_list = [i[1][0] for i in data]

    return (id_list,(tra_list,sag_list),label_list)

class SMdataset_for_pretraining(Dataset): #预训练用的dataset，不用管
    def __init__(self, path,illness,config):
        self.config = config
        data0 = []
        data1 = []
        for x in os.listdir(path+'\\'+illness+'0'):
            data0.append((path+'\\'+illness+'0\\'+x,0))
        for x in os.listdir(path+'\\'+illness+'1'):
            data0.append((path+'\\'+illness+'1\\'+x,1))
        
        self.data = data0+data1
        
        plain_data = [(x,self.config.plain_transforms) for x in self.data]
        rotate_data = [(x,self.config.rotate_transforms) for x in self.data]
        
        self.total_data = plain_data + rotate_data
        
    def __getitem__(self, index):
        (img_path,img_label),transforms = self.total_data[index]
        img = Image.open(img_path)
        img = transforms(img)
        
        return (img,), img_label

    def __len__(self):
        return len(self.total_data)


class SMdataset(Dataset): #主要使用的dataset类，在这里修改
    def __init__(self, config,data,unlabled_data,sag_list,augmentation = False):
       self.config = config
       self.sag_list = sag_list
       self.labelled = data
       self.unlabelled = unlabled_data
       tmp = []
       if augmentation: #数据增强，实际上就是在复制样本
        for x in self.labelled:
            for m in range(1): #复制次数，range里的数字随意改动 
                if x[1] == 2: #腰椎不稳类数量较少，所以额外的进行复制
                    for i in range(3): #额外复制次数
                        tmp.append(x)
                tmp.append(x) #复制
       self.labelled = self.labelled + tmp #合并复制的与原来的样本

       self.samples = self.labelled #samples为最终使用的样本集合变量，在getitem中使用
        
    def __getitem__(self, index):
        img_path,img_label,transform = self.samples[index] #读取一个样本
        #------这一部分是测试一致性正则用的，可以不用管，实际也没用
        if img_label == 4:
            sag_list = []
            tra_list = []
            for i in range(2):
                sag = torch.eye(256).unsqueeze(0).unsqueeze(0).repeat(len(self.sag_list),1,1,1)
                for t,x in enumerate(self.sag_list):
                    for m in os.listdir(img_path + '//' + 'SAG'):
                        if m[0:5] == x:
                            img = Image.open(img_path + '//' + 'SAG'+'//'+m)
                            sag[t] = transform(img)

                tra = transform(Image.open(img_path + '//' + 'TRA'+'//'+ os.listdir(img_path + '//' + 'TRA')[0]))

                sag_list.append(sag)
                tra_list.append(tra)

            sample_id = img_path.split('//')[-1]
            return sample_id,(tuple(tra_list),tuple(sag_list)), img_label
        #----------------------------------------------------
        #读取样本并进行各种转换
        sag = torch.eye(256).unsqueeze(0).unsqueeze(0).repeat(len(self.sag_list),1,1,1)
        for t,x in enumerate(self.sag_list):
            for m in os.listdir(img_path + '//' + 'SAG'):
                if m[0:5] == x:
                    img = Image.open(img_path + '//' + 'SAG'+'//'+m)
                    sag[t] = transform(img)

        tra = transform(Image.open(img_path + '//' + 'TRA'+'//'+ os.listdir(img_path + '//' + 'TRA')[0]))
        sample_id = img_path.split('//')[-1]
        return sample_id,(tra,sag), img_label #最终输出的格式

    def __len__(self):
        return len(self.samples)

    def switch_to_three_classification(self): #转换成三分类时，需要把原来的样本的类别进行修改，改成2
        f = open(self.config.Li_list) #腰椎不稳类别的样本名被放置在txt文件中
        Li_list = ''.join(f.readlines()).split('\n')
        for i in range(len(self.samples)):
            if self.samples[i][0].split('//')[-1] in Li_list:
                self.samples[i][1] = 2 #修改样本类别


def straitified_split(samples_p,samples_n,train_split,config): #控制划分数据集的细节，使得各类别在训练和测试集中满足一定比例
    samples_p1 = []
    samples_p2 = []
    f = open(config.Li_list)
    Li_list = ''.join(f.readlines()).split('\n')
    for i in range(len(samples_p)):
        if samples_p[i][0].split('//')[-1] in Li_list:
            samples_p2.append(samples_p[i])
        else:
            samples_p1.append(samples_p[i])

    p1_index = set(range(len(samples_p1)))
    p2_index = set(range(len(samples_p2)))
    n_index = set(range(len(samples_n)))
    train_p1_index = set(np.random.choice(list(p1_index),int(train_split*len(p1_index)),replace=False))
    train_p2_index = set(np.random.choice(list(p2_index),int(train_split*len(p2_index)),replace=False))
    train_n_index = set(np.random.choice(list(n_index),int(train_split*len(n_index)),replace=False))
    test_p1_index = p1_index - train_p1_index
    test_p2_index = p2_index - train_p2_index
    test_n_index = n_index - train_n_index

    train_p1 = [samples_p1[x] for x in list(train_p1_index)]
    train_p2 = [samples_p2[x] for x in list(train_p2_index)]
    train_n = [samples_n[x] for x in list(train_n_index)]

    test_p1 = [samples_p1[x] for x in list(test_p1_index)]
    test_p2 = [samples_p2[x] for x in list(test_p2_index)]
    test_n = [samples_n[x] for x in list(test_n_index)]

    print("Train negative samples:",len(train_n))
    print("Train positive_1 samples:",len(train_p1))
    print("Train positive_2 samples:",len(train_p2))
    print("Test negative samples:",len(test_n))
    print("Test positive_1 samples:",len(test_p1))
    print("Test positive_2 samples:",len(test_p2))    

    return train_p1+train_p2+train_n, test_p1+test_p2+test_n


def load_dataset(config,sag_list,train_split,from_trained = False): #读取数据集，from_trained控制是否使用预处理完的数据集（经过YOLO裁剪过的数据）
    data_path =  config.data_path
    save_path = config.tmp_save_path
    if not from_trained: #使用yolo裁剪
        yolo_tra = yolo('TRA')
        yolo_sag = yolo('SAG')
        if not os.path.exists(save_path):
            os.mkdir(save_path)
        for i in os.listdir(data_path):
            i_path = data_path + '\\' + i
            if not os.path.exists(save_path+'\\'+i):
                os.mkdir(save_path+'\\'+i)
            
            for t in os.listdir(i_path + '\\' +'SAG'):
                sag_save_path = save_path+'\\'+i+'\\'+'SAG'
                if not os.path.exists(sag_save_path):
                    os.mkdir(sag_save_path)
                
                img = Image.open(i_path+'\\' +'SAG'+'\\'+t)
                yolo_sag.detect_image(img,sag_save_path,crop = True)
        
            tra_save_path = save_path+'\\'+i+'\\'+'TRA'
            if not os.path.exists(tra_save_path):
                os.mkdir(tra_save_path)
            
            for t in os.listdir(i_path + '\\' +'TRA'):
                img = Image.open(i_path+'\\' +'TRA'+'\\'+t)
                yolo_tra.detect_image(img,tra_save_path,crop = True,img_type = 'TRA')
    data_path = save_path
    index = {'L5-S1.jpg','L4-L5.jpg','L3-L4.jpg','L2-L3.jpg','L1-L2.jpg'}
    incomplete = set()
    for x in os.listdir(data_path):
        if len(index -  set(os.listdir(data_path+'//'+x+'//'+'SAG'))) != 0:
               print(x,' missing SAG')
               incomplete.update({x})
        if len(os.listdir(data_path+'//'+x+'//'+'TRA'))==0:
            print(x,' missing TRA')
            incomplete.update({x})
    complete_data = list(set(os.listdir(data_path)) - incomplete) #complete_data包含sag和tra完整切割的样本
    samples_p = [] #正样本集合，标注为1
    samples_n = [] #负样本集合，标注为0
    samples_u = [] #无标签样本集合，标注为3
    for x,i in enumerate(complete_data):
        if i[0:6] == 'normal':
           samples_n.append([data_path+'//'+i,0,config.color_transforms])
        elif i[0:10] == 'unlabelled':
           samples_u.append([data_path+'//'+i,3,config.color_transforms])   
        else:
           samples_p.append([data_path+'//'+i,1,config.color_transforms])

    train_data,test_data = straitified_split(samples_p,samples_n,train_split,config) #划分数据集

    return SMdataset(config,train_data,samples_u,sag_list,augmentation = True),SMdataset(config,test_data,samples_u,sag_list,augmentation = True) #返回训练集和测试集
    



class SIMdataset(Dataset): #孪生神经网络dataset
    def __init__(self, config,data,sag_list,augmentation = False):
        self.config = config
        self.data = data
        self.sag_list = sag_list
        
        data0 = []
        data1 = []
        for i in data:
            if i[1] == 0:
                data0.append(i)
            else:
                data1.append(i)

        pos_pair1 = itertools.combinations(data1, 2)
        pos_pair1 = itertools.product(pos_pair1, [1])
        pos_pair1 = list(pos_pair1)
        
        pos_pair2 = itertools.combinations(data0, 2)
        pos_pair2 = itertools.product(pos_pair2, [1])
        pos_pair2 = list(pos_pair2)
        
        pos_pair = pos_pair1 + pos_pair2
        
        neg_pair = itertools.product(data0, data1)
        neg_pair = list(neg_pair)
        neg_pair = itertools.product(neg_pair, [0])
        neg_pair = list(neg_pair)
        
        self.data = neg_pair + pos_pair
        
    def __getitem__(self, index):
         ((img_path1,img_label1,transform1),(img_path2,img_label2,transform2)),label = self.data[index]
         
         sag1 = {}
         for x in os.listdir(img_path1 + '//' + 'SAG'):
             if x[0:5] in self.sag_list:
                 img = Image.open(img_path1 + '//' + 'SAG'+'//'+x)
                 sag1[x[0:5]] = transform1(img)
         tra1 = transform1(Image.open(img_path1 + '//' + 'TRA'+'//'+ os.listdir(img_path1 + '//' + 'TRA')[0]))
         sample_id1 = img_path1.split('//')[-1]

         sag2 = {}
         for x in os.listdir(img_path2 + '//' + 'SAG'):
             if x[0:5] in self.sag_list:
                 img = Image.open(img_path2 + '//' + 'SAG'+'//'+x)
                 sag2[x[0:5]] = transform1(img)
         tra2 = transform2(Image.open(img_path2 + '//' + 'TRA'+'//'+ os.listdir(img_path2 + '//' + 'TRA')[0]))
         sample_id2 = img_path2.split('//')[-1]

         return (sample_id1,tra1,sag1),(sample_id2,tra2,sag2),label 

    def __len__(self):
        return len(self.data)





    